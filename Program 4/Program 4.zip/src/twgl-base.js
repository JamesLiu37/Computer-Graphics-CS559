define('main', [
    './twgl',
  ], function(
    twgl
  ) {
    "use strict";

    return twgl;
});





